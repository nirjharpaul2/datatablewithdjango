from django.contrib import admin
from .models import Returntooffice, Post, SiteContacts

admin.site.register(Returntooffice)
admin.site.register(Post)
admin.site.register(SiteContacts)
